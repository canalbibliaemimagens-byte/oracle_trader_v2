"""
Oracle Trader v2 - Trading

Lógica de execução e gerenciamento de risco.

Módulos:
- executor.py: Execução de ordens
- risk_manager.py: DD, SL Protection, TP Global
- position_manager.py: Gestão de posições
- paper_trade.py: Simulação virtual
"""

# Será populado na Fase 2
