"""
Oracle Trader v2 - Core

Engine principal e máquina de estados.

Módulos:
- engine.py: Loop principal orquestrador
- state_machine.py: Transições de estado dos símbolos
- config.py: Configurações runtime
"""

# Será populado na Fase 2
